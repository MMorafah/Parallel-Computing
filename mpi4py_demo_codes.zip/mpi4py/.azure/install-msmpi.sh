#!/bin/bash
_dir=$(dirname ${BASH_SOURCE[0]})
pwsh $_dir/install-msmpi.ps1
